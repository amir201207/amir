![file-cracker](https://user-images.githubusercontent.com/75953873/143357868-f7be94aa-c2a1-48f9-a8a8-2c343975f1ca.png)

Crack password ZIP, RAR and PDF with dictionary.

![1](https://user-images.githubusercontent.com/75953873/143340382-344c3e4c-cec6-4908-806b-ab9bace1cf81.png)

### [EXAMPLE] Cracking PDF password:
![2](https://user-images.githubusercontent.com/75953873/143340641-df1b606e-c48d-4412-b7d5-5f2ab5e185e5.png)


#### Install:

```
• git clone https://github.com/R3LI4NT/File-Cracker
• cd File-Cracker
• pip3 install -r requirements.txt
• python3 file_cracker.py
```

#### Requirements:

```
zipfile
rarfile
pikepdf
tqdm
```
